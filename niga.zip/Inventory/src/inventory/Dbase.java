/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package inventory;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author ljapo
 */
public class Dbase {
    public static Connection DBConnect(){
       Connection con=null;
        String sUrl, sUser, sPass;
        sUrl = "jdbc:mysql://localhost:3306/avrene";
        sUser = "root";
        sPass = "";
        try{
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection(sUrl, sUser, sPass);
            Statement st = con.createStatement();
            System.out.println("CONNECTED SUCCESSFULLY =)");
        }catch(ClassNotFoundException | SQLException e){
            System.out.println(""+e);
        }
        
        return con;
    }

    Connection getConnection() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
