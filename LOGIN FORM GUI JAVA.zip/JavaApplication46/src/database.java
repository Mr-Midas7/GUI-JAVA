/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author ljapo
 */
public class database {

   private static String FirstNamee;
   private String LastNamee;
    private String Contactt;
    private String malee;
    private String Femalee;
    private String UserNamee;
    private String PassWordd;
private String sex;
    public database(String FirstNamee, String LastNamee, String Contactt, String UserNamee, String PassWordd,String sex) {
        this.FirstNamee = FirstNamee;
        this.LastNamee = LastNamee;
        this.Contactt = Contactt;
        this.UserNamee = UserNamee;
        this.PassWordd = PassWordd;
        this.sex=sex;
        this.malee=malee;
        this.Femalee=Femalee;
        
    }

    public static String getFirstNamee() {
        return FirstNamee;
    }
    
    public String getLastNamee() {
        return LastNamee;
    }

    public String getContactt() {
        return Contactt;
    }

    public String getUserNamee() {
        return UserNamee;
    }

    public String getPassWordd() {
        return PassWordd;
    }

    public String getmalee() {
        return malee;
    }

    public String getFemalee() {
        return Femalee;
    }
public static void setFirstNamee(String FirstName){
    database.FirstNamee=FirstNamee;
}
}
