/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package inventory;

import java.awt.HeadlessException;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Date;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import java.sql.*;
import java.text.SimpleDateFormat;

/**
 *
 * @author ljapo
 */
public class Front extends javax.swing.JFrame {

    /**
     * Creates new form Front
     */
    public Front() {
        initComponents();

        loadData();
        updateDisplayedSums();

        date_Chooser2.addPropertyChangeListener(evt -> {
            if ("date".equals(evt.getPropertyName())) {
                java.util.Date selectedDate = (java.util.Date) evt.getNewValue();
                if (selectedDate != null) {
                    dateC(new java.sql.Date(selectedDate.getTime())); // Call dateC with the selected date
                    updateDisplayedSums(); // Update sums with the selected date
                }
            }
        });
    }
////////////////////////////////////////////////////////////////////////////////

    
    public void cnname(String name) {
         String query = "SELECT * FROM front WHERE name = ?";
    
    try (Connection con = Dbase.DBConnect(); 
         PreparedStatement pst = con.prepareStatement(query)) {
        
        // Set the name parameter
        pst.setString(1, name);
        
        try (ResultSet rs = pst.executeQuery()) {
            DefaultTableModel tb3Model = (DefaultTableModel) table3.getModel(); // Assuming table3 is defined
            tb3Model.setRowCount(0); // Clear existing rows
            
            while (rs.next()) {
               
                String nam = rs.getString("name");
                Date date = rs.getDate("date");
                String pin = rs.getString("pinipig");
                String pop = rs.getString("popsicle");
                

                // Add the retrieved data to table3
                tb3Model.addRow(new Object[]{nam, date, pin, pop});
            }
        }
    } catch (HeadlessException | SQLException e) {
        JOptionPane.showMessageDialog(this, "Error: " + e.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
        e.printStackTrace();
    }

    // Call methods to calculate totals for pinipig and popsicle
    worktotalp(name);
    worktotalpop(name);

    }

    public void worktotalp(String name) {
        String query = "Select Sum(pinipig) from front where name=?";
        try (Connection con = Dbase.DBConnect(); PreparedStatement pst = con.prepareStatement(query)) {
            // Set the name parameter
            pst.setString(1, name);

            try (ResultSet rs = pst.executeQuery()) {
                if (rs.next()) {
                    double sumpinipig = rs.getDouble(1); // Get the sum from the result set
                    totalp.setText(String.valueOf(sumpinipig));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            totalp.setText("Error: " + e.getMessage()); // Display error message if needed
        }
    }

    public void worktotalpop(String name) {
        String query = "Select Sum(popsicle) from front where name=?";
        try (Connection con = Dbase.DBConnect(); PreparedStatement pst = con.prepareStatement(query)) {
            pst.setString(1, name);
            try (ResultSet rs = pst.executeQuery()) {
                if (rs.next()) {
                    double sumpop = rs.getDouble(1); // Get the sum from the result set
                    totalpop.setText(String.valueOf(sumpop));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            totalpop.setText("Error: " + e.getMessage()); // Display error message if needed
        }
    }
////////////////////////////////////////////////////////////////////////////

    public void showe(String sDate) {
        String query = "SELECT SUM(remitt) FROM front WHERE date=?";
        try (Connection con = Dbase.DBConnect(); PreparedStatement pst = con.prepareStatement(query)) {

            pst.setString(1, sDate);
            try (ResultSet rs = pst.executeQuery()) {
                if (rs.next()) {
                    double sumRemitt = rs.getDouble(1); // Get the sum from the result set
                    ee.setText(String.valueOf(sumRemitt)); // Display the sum in the component
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            ee.setText("Error: " + e.getMessage()); // Display error message if needed
        }
    }

    public void showp(String sDate) {
        String query = "SELECT SUM(pinipig) FROM front WHERE date=?";
        try (Connection con = Dbase.DBConnect(); PreparedStatement pst = con.prepareStatement(query)) {

            pst.setString(1, sDate);
            try (ResultSet rs = pst.executeQuery()) {
                if (rs.next()) {
                    double sumPinipig = rs.getDouble(1); // Get the sum from the result set
                    pp.setText(String.valueOf(sumPinipig)); // Display the sum in the component
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            pp.setText("Error: " + e.getMessage()); // Display error message if needed
        }
    }

    public void showpo(String sDate) {
        String query = "SELECT SUM(popsicle) FROM front WHERE date=?";
        try (Connection con = Dbase.DBConnect(); PreparedStatement pst = con.prepareStatement(query)) {

            pst.setString(1, sDate);
            try (ResultSet rs = pst.executeQuery()) {
                if (rs.next()) {
                    double sumPopsicle = rs.getDouble(1); // Get the sum from the result set
                    fp.setText(String.valueOf(sumPopsicle)); // Display the sum in the component
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            fp.setText("Error: " + e.getMessage()); // Display error message if needed
        }
    }

    private void updateDisplayedSums() {
        // Get the selected date from the date chooser
        java.util.Date selectedDate = date_Chooser2.getDate();
        if (selectedDate != null) {
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
            String formattedDate = dateFormat.format(selectedDate);

            // Call the methods to update the displayed sums with the selected date
            showe(formattedDate);
            showp(formattedDate);
            showpo(formattedDate);
        }
    }
//////////////////////////////////////////////////////////////////////////////////////////

    private void updateNoValues() {
        String resetRowNumQuery = "SET @rownum := 0;";
        String updateQuery = "UPDATE front SET no = (@rownum := @rownum + 1) ORDER BY no;";

        try (Connection con = Dbase.DBConnect(); Statement stmt = con.createStatement()) {

            // First execute the query to reset the row number
            stmt.execute(resetRowNumQuery);

            // Then execute the update query to renumber the 'no' column
            stmt.executeUpdate(updateQuery);

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error updating 'no' values: " + e.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }
    }

    /*
public void retrieveDataForTable2() {
    String query = "SELECT * FROM front"; // Adjust the query as needed

    try (Connection con = Dbase.DBConnect(); 
         Statement st = con.createStatement(); 
         ResultSet rs = st.executeQuery(query)) {

        DefaultTableModel tb2Model = (DefaultTableModel) Table2.getModel();
        tb2Model.setRowCount(0); // Clear existing rows

        while (rs.next()) {
            String no = rs.getString("no");
            String nam = rs.getString("name");
            Date date = rs.getDate("date");
            String pin = rs.getString("pinipig");
            String pop = rs.getString("popsicle");
            String ic = rs.getString("ice");
            String sa = rs.getString("salt");
            String rem = rs.getString("remitt");
            String re = rs.getString("ret");

            // Add the retrieved data to the table model
            tb2Model.addRow(new Object[]{no, nam, date, pin, pop, ic, sa, rem, re});
        }
    } catch (HeadlessException | SQLException e) {
        JOptionPane.showMessageDialog(this, "Error: " + e.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
        e.printStackTrace();
    }
}*/
    private void loadData() {
        String query;
        query = "SELECT * from front";
        
        try (Connection con = Dbase.DBConnect(); Statement st = con.createStatement(); ResultSet rs = st.executeQuery(query);) {

            DefaultTableModel tb1Model = (DefaultTableModel) table.getModel();
            DefaultTableModel tb2Model = (DefaultTableModel) Table2.getModel();
           
            tb1Model.setRowCount(0); // Clear existing rows
            tb2Model.setRowCount(0);
           

            while (rs.next()) {
                String no = rs.getString("no");
                String nam = rs.getString("name");
                Date date = rs.getDate("date");
                String pin = rs.getString("pinipig");
                String po = rs.getString("popsicle");
                String ic = rs.getString("ice");
                String sa = rs.getString("salt");
                String rem = rs.getString("remitt");
                String re = rs.getString("ret");

                tb1Model.addRow(new Object[]{no, nam, date, pin, po, ic, sa, rem, re});
                tb2Model.addRow(new Object[]{no, nam, date, pin, po, ic, sa, rem, re});
                
            }
            rs.close();
            st.close();
            con.close();
        } catch (HeadlessException | SQLException e) {
            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }
    }
////////////////////////////////////////////////////////////////////////////////////////////////////

    public void dateC(Date selectedDate) {
        // Format the date to match the database format (assuming it's stored as 'YYYY-MM-DD')
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        String formattedDate = dateFormat.format(selectedDate);

        String query = "SELECT * FROM front WHERE date = ?";

        try (Connection con = Dbase.DBConnect(); PreparedStatement pst = con.prepareStatement(query)) {

            // Set the date parameter
            pst.setString(1, formattedDate);

            try (ResultSet rs = pst.executeQuery()) {
                DefaultTableModel tb2Model = (DefaultTableModel) Table2.getModel();
                tb2Model.setRowCount(0); // Clear existing rows

                while (rs.next()) {
                    String no = rs.getString("no");
                    String nam = rs.getString("name");
                    Date date = rs.getDate("date");
                    String pin = rs.getString("pinipig");
                    String pop = rs.getString("popsicle");
                    String ic = rs.getString("ice");
                    String sal = rs.getString("salt");
                    String rem = rs.getString("remitt");
                    String re = rs.getString("ret");

                    // Add the retrieved data to the table model
                    tb2Model.addRow(new Object[]{no, nam, date, pin, pop, ic, sal, rem, re});
                }
                // Update the sums based on the selected date
                showe(formattedDate);
                showp(formattedDate);
                showpo(formattedDate);
            }
        } catch (HeadlessException | SQLException e) {
            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }

    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jDatePickerUtil1 = new org.jdatepicker.util.JDatePickerUtil();
        jPanel1 = new javax.swing.JPanel();
        jLabel31 = new javax.swing.JLabel();
        jLabel32 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jLabel23 = new javax.swing.JLabel();
        jLabel24 = new javax.swing.JLabel();
        jLabel25 = new javax.swing.JLabel();
        jLabel26 = new javax.swing.JLabel();
        jLabel27 = new javax.swing.JLabel();
        jLabel28 = new javax.swing.JLabel();
        jLabel29 = new javax.swing.JLabel();
        jLabel30 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        addDelivery = new javax.swing.JButton();
        delDelivery = new javax.swing.JButton();
        dashDelivery = new javax.swing.JButton();
        chartDelivery = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        parentPanel = new javax.swing.JPanel();
        one = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        name = new javax.swing.JTextField();
        pinipig = new javax.swing.JTextField();
        popsicle = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        ice = new javax.swing.JTextField();
        salt = new javax.swing.JTextField();
        add = new javax.swing.JButton();
        clear = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        table = new javax.swing.JTable();
        jLabel10 = new javax.swing.JLabel();
        date_Chooser = new com.toedter.calendar.JDateChooser();
        jLabel7 = new javax.swing.JLabel();
        remitt = new javax.swing.JTextField();
        jLabel20 = new javax.swing.JLabel();
        ret = new javax.swing.JTextField();
        update = new javax.swing.JButton();
        delete = new javax.swing.JButton();
        noo = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        two = new javax.swing.JPanel();
        jScrollPane3 = new javax.swing.JScrollPane();
        table3 = new javax.swing.JTable();
        jLabel16 = new javax.swing.JLabel();
        Cname = new javax.swing.JTextField();
        jLabel19 = new javax.swing.JLabel();
        jLabel21 = new javax.swing.JLabel();
        jLabel33 = new javax.swing.JLabel();
        totalp = new javax.swing.JLabel();
        totalpop = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        three = new javax.swing.JPanel();
        ee = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        fp = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        pp = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        date_Chooser2 = new com.toedter.calendar.JDateChooser();
        jLabel12 = new javax.swing.JLabel();
        jScrollPane4 = new javax.swing.JScrollPane();
        Table2 = new javax.swing.JTable();
        four = new javax.swing.JPanel();
        jLabel22 = new javax.swing.JLabel();
        jTextField2 = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(255, 204, 255));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel31.setFont(new java.awt.Font("Sitka Text", 1, 36)); // NOI18N
        jLabel31.setForeground(new java.awt.Color(0, 0, 0));
        jLabel31.setText("AVRENE");
        jPanel1.add(jLabel31, new org.netbeans.lib.awtextra.AbsoluteConstraints(550, 20, 160, 40));

        jLabel32.setIcon(new javax.swing.ImageIcon(getClass().getResource("/inventory/yummy-ezgif.com-resize.png"))); // NOI18N
        jPanel1.add(jLabel32, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 10, -1, -1));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1190, 50));

        jPanel2.setBackground(new java.awt.Color(102, 102, 102));
        jPanel2.setForeground(new java.awt.Color(153, 153, 153));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel23.setIcon(new javax.swing.ImageIcon(getClass().getResource("/inventory/home-ezgif.com-resize (1).png"))); // NOI18N
        jPanel2.add(jLabel23, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 140, 30, 30));

        jLabel24.setIcon(new javax.swing.ImageIcon(getClass().getResource("/inventory/cardboard-ezgif.com-resize.png"))); // NOI18N
        jPanel2.add(jLabel24, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 210, -1, -1));

        jLabel25.setIcon(new javax.swing.ImageIcon(getClass().getResource("/inventory/people-ezgif.com-resize.png"))); // NOI18N
        jPanel2.add(jLabel25, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 80, -1, -1));

        jLabel26.setIcon(new javax.swing.ImageIcon(getClass().getResource("/inventory/add1-ezgif.com-resize (1).png"))); // NOI18N
        jPanel2.add(jLabel26, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 30, -1, -1));

        jLabel27.setText("ADD");
        jPanel2.add(jLabel27, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 20, -1, 30));

        jLabel28.setText("SEARCH");
        jPanel2.add(jLabel28, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 70, -1, 40));

        jLabel29.setText("DASHBOARD");
        jPanel2.add(jLabel29, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 140, -1, 30));

        jLabel30.setText("DAMAGE");
        jPanel2.add(jLabel30, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 210, -1, -1));

        jLabel6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/inventory/logout-ezgif.com-resize.png"))); // NOI18N
        jPanel2.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 500, 20, 30));

        addDelivery.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addDeliveryActionPerformed(evt);
            }
        });
        jPanel2.add(addDelivery, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 190, 60));

        delDelivery.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                delDeliveryActionPerformed(evt);
            }
        });
        jPanel2.add(delDelivery, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 60, 190, 60));

        dashDelivery.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                dashDeliveryActionPerformed(evt);
            }
        });
        jPanel2.add(dashDelivery, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 120, 190, 70));

        chartDelivery.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chartDeliveryActionPerformed(evt);
            }
        });
        jPanel2.add(chartDelivery, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 190, 190, 60));

        jButton3.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton3.setForeground(new java.awt.Color(0, 0, 0));
        jButton3.setText("LOGOUT");
        jButton3.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, null, null, new java.awt.Color(51, 51, 51), new java.awt.Color(0, 0, 0)));
        jButton3.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jButton3.setName(""); // NOI18N
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        jPanel2.add(jButton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 490, 190, 50));

        getContentPane().add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 50, 190, 540));

        parentPanel.setBackground(new java.awt.Color(255, 255, 255));
        parentPanel.setLayout(new java.awt.CardLayout());

        one.setBackground(new java.awt.Color(255, 255, 255));
        one.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel3.setBackground(new java.awt.Color(255, 204, 255));
        jPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setForeground(new java.awt.Color(0, 0, 0));
        jLabel1.setText("NAME:");
        jPanel3.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 80, -1, -1));

        jLabel2.setForeground(new java.awt.Color(0, 0, 0));
        jLabel2.setText("QUANTITY");
        jPanel3.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 170, -1, -1));

        jLabel4.setForeground(new java.awt.Color(0, 0, 0));
        jLabel4.setText("PINIPIG:");
        jPanel3.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 190, 56, 20));

        jLabel5.setForeground(new java.awt.Color(0, 0, 0));
        jLabel5.setText("POPSICLE:");
        jPanel3.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 220, 56, 20));

        name.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nameActionPerformed(evt);
            }
        });
        jPanel3.add(name, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 78, 130, -1));
        jPanel3.add(pinipig, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 190, 130, -1));
        jPanel3.add(popsicle, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 220, 130, -1));

        jLabel8.setForeground(new java.awt.Color(0, 0, 0));
        jLabel8.setText("ICE:");
        jPanel3.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 250, 37, 20));

        jLabel9.setForeground(new java.awt.Color(0, 0, 0));
        jLabel9.setText("SALT:");
        jPanel3.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 280, 60, 30));
        jPanel3.add(ice, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 250, 130, -1));
        jPanel3.add(salt, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 280, 130, -1));

        add.setBackground(new java.awt.Color(0, 204, 204));
        add.setForeground(new java.awt.Color(0, 0, 0));
        add.setIcon(new javax.swing.ImageIcon(getClass().getResource("/inventory/add-ezgif.com-resize.png"))); // NOI18N
        add.setText("   ADD");
        add.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, null, null, new java.awt.Color(51, 51, 51), new java.awt.Color(0, 0, 0)));
        add.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addActionPerformed(evt);
            }
        });
        jPanel3.add(add, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 412, 80, 30));

        clear.setBackground(new java.awt.Color(255, 102, 255));
        clear.setForeground(new java.awt.Color(0, 0, 0));
        clear.setIcon(new javax.swing.ImageIcon(getClass().getResource("/inventory/clean-ezgif.com-resize.png"))); // NOI18N
        clear.setText("CLEAR");
        clear.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, null, null, new java.awt.Color(51, 51, 51), new java.awt.Color(0, 0, 0)));
        clear.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                clearActionPerformed(evt);
            }
        });
        jPanel3.add(clear, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 412, 80, 30));

        table.setBackground(new java.awt.Color(255, 255, 255));
        table.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        table.setForeground(new java.awt.Color(0, 0, 0));
        table.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null}
            },
            new String [] {
                "NO.", "NAME", "DATE", "PINIPIG", "POPSICLE", "ICE", "SALT", "REMITT", "RETURN"
            }
        ));
        table.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        table.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tableMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(table);

        jPanel3.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 0, 660, 490));

        jLabel10.setForeground(new java.awt.Color(0, 0, 0));
        jLabel10.setText("DATE:");
        jPanel3.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 100, 43, 40));
        jPanel3.add(date_Chooser, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 110, 130, -1));

        jLabel7.setForeground(new java.awt.Color(0, 0, 0));
        jLabel7.setText("REMITT:");
        jPanel3.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 310, -1, 20));
        jPanel3.add(remitt, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 310, 130, -1));

        jLabel20.setForeground(new java.awt.Color(0, 0, 0));
        jLabel20.setText("RETURN:");
        jPanel3.add(jLabel20, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 340, -1, 30));
        jPanel3.add(ret, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 340, 130, -1));

        update.setBackground(new java.awt.Color(0, 255, 102));
        update.setForeground(new java.awt.Color(0, 0, 0));
        update.setIcon(new javax.swing.ImageIcon(getClass().getResource("/inventory/refresh-ezgif.com-resize.png"))); // NOI18N
        update.setText("UPDATE");
        update.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, null, null, new java.awt.Color(51, 51, 51), new java.awt.Color(0, 0, 0)));
        update.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                updateActionPerformed(evt);
            }
        });
        jPanel3.add(update, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 450, 80, 30));

        delete.setBackground(new java.awt.Color(255, 102, 102));
        delete.setForeground(new java.awt.Color(0, 0, 0));
        delete.setIcon(new javax.swing.ImageIcon(getClass().getResource("/inventory/trash-ezgif.com-resize.png"))); // NOI18N
        delete.setText("DELETE");
        delete.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, null, null, new java.awt.Color(51, 51, 51), new java.awt.Color(0, 0, 0)));
        delete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteActionPerformed(evt);
            }
        });
        jPanel3.add(delete, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 450, 80, 30));

        noo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nooActionPerformed(evt);
            }
        });
        jPanel3.add(noo, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 50, 40, -1));

        jLabel3.setForeground(new java.awt.Color(0, 0, 0));
        jLabel3.setText("NO.");
        jPanel3.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 50, -1, -1));

        one.add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(6, 16, 980, 500));

        parentPanel.add(one, "card2");

        two.setBackground(new java.awt.Color(255, 255, 255));
        two.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        table3.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "NAME", "DATE", "PINIPIG", "POPSICLE"
            }
        ));
        table3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                table3MouseClicked(evt);
            }
        });
        table3.addComponentListener(new java.awt.event.ComponentAdapter() {
            public void componentShown(java.awt.event.ComponentEvent evt) {
                table3ComponentShown(evt);
            }
        });
        jScrollPane3.setViewportView(table3);

        two.add(jScrollPane3, new org.netbeans.lib.awtextra.AbsoluteConstraints(212, 30, 700, 480));

        jLabel16.setForeground(new java.awt.Color(0, 0, 0));
        jLabel16.setText("NAME:");
        two.add(jLabel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 60, -1, -1));

        Cname.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CnameActionPerformed(evt);
            }
        });
        two.add(Cname, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 80, 90, -1));

        jLabel19.setForeground(new java.awt.Color(0, 0, 0));
        jLabel19.setText("TOTAL SOLD");
        two.add(jLabel19, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 180, 90, -1));

        jLabel21.setForeground(new java.awt.Color(0, 0, 0));
        jLabel21.setText("PINIPIG:");
        two.add(jLabel21, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 230, -1, 20));

        jLabel33.setForeground(new java.awt.Color(0, 0, 0));
        jLabel33.setText("POPSICLE:");
        two.add(jLabel33, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 266, -1, 30));

        totalp.setBackground(new java.awt.Color(0, 204, 204));
        totalp.setBorder(new javax.swing.border.MatteBorder(null));
        two.add(totalp, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 230, 60, 20));

        totalpop.setBorder(new javax.swing.border.MatteBorder(null));
        two.add(totalpop, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 270, 60, 20));

        jButton1.setBackground(new java.awt.Color(204, 204, 255));
        jButton1.setForeground(new java.awt.Color(0, 0, 0));
        jButton1.setText("SEARCH");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        two.add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 120, -1, -1));

        parentPanel.add(two, "card3");

        three.setBackground(new java.awt.Color(204, 255, 255));
        three.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        ee.setBackground(new java.awt.Color(255, 255, 255));
        ee.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        three.add(ee, new org.netbeans.lib.awtextra.AbsoluteConstraints(97, 60, 103, 29));

        jLabel13.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel13.setForeground(new java.awt.Color(0, 0, 0));
        jLabel13.setText("AVRENE EARNS");
        three.add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 20, -1, -1));

        jLabel14.setForeground(new java.awt.Color(0, 0, 0));
        jLabel14.setText("EARNINGS");
        three.add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(28, 60, 60, 29));

        jLabel15.setForeground(new java.awt.Color(0, 0, 0));
        jLabel15.setText("FLAVORED ");
        three.add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 270, -1, 40));

        fp.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        three.add(fp, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 280, 105, 29));

        jLabel17.setForeground(new java.awt.Color(0, 0, 0));
        jLabel17.setText("POPSICLE");
        three.add(jLabel17, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 280, 61, 40));

        jLabel18.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel18.setForeground(new java.awt.Color(0, 0, 0));
        jLabel18.setText("PRODUCT SELL");
        three.add(jLabel18, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 190, -1, -1));

        pp.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        three.add(pp, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 230, 102, 29));

        jLabel11.setForeground(new java.awt.Color(0, 0, 0));
        jLabel11.setText("PINIPIG");
        three.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 230, -1, 30));
        three.add(date_Chooser2, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 110, -1, -1));

        jLabel12.setForeground(new java.awt.Color(0, 0, 0));
        jLabel12.setText("DATE");
        three.add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 110, -1, 30));

        Table2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null}
            },
            new String [] {
                "NO.", "NAME", "DATE", "PINIPIG", "POPSICLE", "ICE", "SALT", "REMITT", "RETURN"
            }
        ));
        jScrollPane4.setViewportView(Table2);

        three.add(jScrollPane4, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 20, 700, -1));

        parentPanel.add(three, "card4");

        four.setBackground(new java.awt.Color(204, 255, 204));
        four.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel22.setForeground(new java.awt.Color(0, 0, 0));
        jLabel22.setText("DAMAGE");
        four.add(jLabel22, new org.netbeans.lib.awtextra.AbsoluteConstraints(49, 80, 59, -1));
        four.add(jTextField2, new org.netbeans.lib.awtextra.AbsoluteConstraints(114, 77, 71, -1));

        parentPanel.add(four, "card5");

        getContentPane().add(parentPanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 50, 1000, 540));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void nameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nameActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_nameActionPerformed

    private void addActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addActionPerformed

        String query = "INSERT INTO front (no, name, date, pinipig, popsicle, ice, salt, remitt, ret) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
        String checkQuery = "SELECT COUNT(*) FROM front WHERE no = ?"; // Query to check for existing "no"

        // Get the value of "no" once
        String noValue = noo.getText();

        // Validate inputs
        if (noValue.isEmpty() || name.getText().isEmpty() || date_Chooser.getDate() == null
                || pinipig.getText().isEmpty() || popsicle.getText().isEmpty() || ice.getText().isEmpty()
                || salt.getText().isEmpty() || remitt.getText().isEmpty() || ret.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please fill all fields", "Error", JOptionPane.ERROR_MESSAGE);
            return; // Exit if validation fails
        }

        // Validate numeric inputs
        try {
            Integer.valueOf(pinipig.getText());
            Integer.valueOf(popsicle.getText());
            Integer.valueOf(ice.getText());
            Integer.parseInt(salt.getText());
            Integer.parseInt(remitt.getText());
            Integer.parseInt(ret.getText());
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Please enter valid numbers for quantities", "Error", JOptionPane.ERROR_MESSAGE);
            return; // Exit if any of the quantities are not valid numbers
        }

        // Check if "no" already exists in the database
        try (Connection con = Dbase.DBConnect(); PreparedStatement checkStmt = con.prepareStatement(checkQuery)) {
            checkStmt.setString(1, noValue);
            ResultSet rs = checkStmt.executeQuery();

            if (rs.next() && rs.getInt(1) > 0) { // If count is greater than 0, "no" exists
                JOptionPane.showMessageDialog(this, "The 'no' value already exists. Please use a unique value.", "Error", JOptionPane.ERROR_MESSAGE);
                return; // Exit if "no" is not unique
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
            return; // Exit on error
        }

        // Proceed to insert the new record
        try (Connection con = Dbase.DBConnect(); PreparedStatement insertStmt = con.prepareStatement(query)) {
            insertStmt.setString(1, noValue); // Use the stored noValue
            insertStmt.setString(2, name.getText());
            insertStmt.setDate(3, new java.sql.Date(date_Chooser.getDate().getTime())); // Convert to java.sql.Date
            insertStmt.setString(4, pinipig.getText());
            insertStmt.setString(5, popsicle.getText());
            insertStmt.setString(6, ice.getText());
            insertStmt.setString(7, salt.getText());
            insertStmt.setString(8, remitt.getText());
            insertStmt.setString(9, ret.getText());

            // Execute the insert statement
            if (insertStmt.executeUpdate() > 0) {
                DefaultTableModel tb1Model = (DefaultTableModel) table.getModel();
                tb1Model.addRow(new Object[]{
                    noValue, name.getText(), new java.sql.Date(date_Chooser.getDate().getTime()),
                    pinipig.getText(), popsicle.getText(), ice.getText(),
                    salt.getText(), remitt.getText(), ret.getText()
                });
                loadData();
                updateDisplayedSums();
                JOptionPane.showMessageDialog(null, "Added", "Success", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(this, "Invalid", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }
    }//GEN-LAST:event_addActionPerformed

    private void dashDeliveryActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_dashDeliveryActionPerformed
        parentPanel.removeAll();
        parentPanel.add(three);
        parentPanel.repaint();
        parentPanel.revalidate();
    }//GEN-LAST:event_dashDeliveryActionPerformed

    private void addDeliveryActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addDeliveryActionPerformed
        parentPanel.removeAll();
        parentPanel.add(one);
        parentPanel.repaint();
        parentPanel.revalidate();
    }//GEN-LAST:event_addDeliveryActionPerformed

    private void delDeliveryActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_delDeliveryActionPerformed
        parentPanel.removeAll();
        parentPanel.add(two);
        parentPanel.repaint();
        parentPanel.revalidate();
    }//GEN-LAST:event_delDeliveryActionPerformed

    private void chartDeliveryActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_chartDeliveryActionPerformed
        parentPanel.removeAll();
        parentPanel.add(four);
        parentPanel.repaint();
        parentPanel.revalidate();
    }//GEN-LAST:event_chartDeliveryActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        new login().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_jButton3ActionPerformed

    private void table3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_table3MouseClicked

    }//GEN-LAST:event_table3MouseClicked

    private void clearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_clearActionPerformed
        // delete inputs in jtextfield in code,name,pinipig,popsicle,ice,salt
        noo.setText("");
        name.setText("");
        date_Chooser.setDate(null);
        pinipig.setText("");
        popsicle.setText("");
        ice.setText("");
        salt.setText("");
        remitt.setText("");
        ret.setText("");
    }//GEN-LAST:event_clearActionPerformed

    private void tableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tableMouseClicked
        DefaultTableModel tbModel = (DefaultTableModel) table.getModel();
        String tbno = tbModel.getValueAt(table.getSelectedRow(), 0).toString();
        String tbname = tbModel.getValueAt(table.getSelectedRow(), 1).toString();

        String tbpinipig = tbModel.getValueAt(table.getSelectedRow(), 3).toString();
        String tbpopsicle = tbModel.getValueAt(table.getSelectedRow(), 4).toString();
        String tbice = tbModel.getValueAt(table.getSelectedRow(), 5).toString();
        String tbsalt = tbModel.getValueAt(table.getSelectedRow(), 6).toString();
        String tbremitt = tbModel.getValueAt(table.getSelectedRow(), 7).toString();
        String tbret = tbModel.getValueAt(table.getSelectedRow(), 8).toString();
        //set textfield
        noo.setText(tbno);
        name.setText(tbname);
        // Convert string date to Date object and set it in date chooser
        date_Chooser.setDate((java.util.Date) tbModel.getValueAt(table.getSelectedRow(), 2));
        pinipig.setText(tbpinipig);
        popsicle.setText(tbpopsicle);
        ice.setText(tbice);
        salt.setText(tbsalt);
        remitt.setText(tbremitt);
        ret.setText(tbret);

    }//GEN-LAST:event_tableMouseClicked

    private void table3ComponentShown(java.awt.event.ComponentEvent evt) {//GEN-FIRST:event_table3ComponentShown
        // TODO add your handling code here:
    }//GEN-LAST:event_table3ComponentShown

    private void deleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteActionPerformed

        try (Connection con = Dbase.DBConnect(); Statement st = con.createStatement()) {

            DefaultTableModel tb1Mode = (DefaultTableModel) table.getModel();
            if (table.getSelectedRowCount() == 1) {
                int selectedRow = table.getSelectedRow(); // Get the selected row index
                String noDlete = tb1Mode.getValueAt(selectedRow, 0).toString(); // Assuming the first column is the code

                // Retrieve the values of pinipig, popsicle, and remitt before deletion
                /* String pinipigValue = tb1Mode.getValueAt(selectedRow, 3).toString();
                String popsicleValue = tb1Mode.getValueAt(selectedRow, 4).toString();
                String remittValue = tb1Mode.getValueAt(selectedRow, 7).toString(); */
                // Prepare the DELETE query for both tables
                String deleteQuery = "DELETE  from front where no = ? ";
                try (PreparedStatement pstmt = con.prepareStatement(deleteQuery)) {
                    pstmt.setString(1, noDlete);
                    int rowsAffected = pstmt.executeUpdate();

                    if (rowsAffected > 0) {
                        tb1Mode.removeRow(selectedRow); // Remove the row from the table model
                        JOptionPane.showMessageDialog(null, "DELETE Successful!", "Delete", JOptionPane.INFORMATION_MESSAGE);

                        // Update the 'no' values
                        updateNoValues();
                        // Update the sums after deletion
                        updateDisplayedSums();
                        /*      // Update the sums after deletion
                        double currentPinipigSum = Double.parseDouble(pp.getText());
                        double currentPopsicleSum = Double.parseDouble(fp.getText());
                        double currentRemittSum = Double.parseDouble(ee.getText());

                        // Subtract the deleted values from the current sums
                        currentPinipigSum -= Double.parseDouble(pinipigValue);
                        currentPopsicleSum -= Double.parseDouble(popsicleValue);
                        currentRemittSum -= Double.parseDouble(remittValue);

                        // Update the displayed sums
                        pp.setText(String.valueOf(currentPinipigSum));
                        fp.setText(String.valueOf(currentPopsicleSum));
                        ee.setText(String.valueOf(currentRemittSum));  */
                        loadData();
                    } else {
                        JOptionPane.showMessageDialog(this, "No record deleted.", "Error", JOptionPane.INFORMATION_MESSAGE);
                    }
                }
            } else {
                if (table.getRowCount() == 0) {
                    JOptionPane.showMessageDialog(this, "Table Is Empty", "EMPTY", JOptionPane.INFORMATION_MESSAGE);
                } else {
                    JOptionPane.showMessageDialog(this, "Please Select a Single Row For DELETE");
                }
            }
        } catch (HeadlessException | SQLException e) {
            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }
    }//GEN-LAST:event_deleteActionPerformed

    private void updateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_updateActionPerformed
        String query;

        // Validate if it is an integer
        String noot = noo.getText();
        String pin = pinipig.getText();
        String po = popsicle.getText();
        String ic = ice.getText();
        String sa = salt.getText();
        String re = remitt.getText();
        String r = ret.getText();
        int pinV, poV, icV, reV, rV;

        // Validate inputs
        if (noot.isEmpty() || name.getText().isEmpty() || date_Chooser.getDate() == null || pin.isEmpty() || po.isEmpty() || ic.isEmpty() || sa.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please fill code, name, and date", "Error", JOptionPane.ERROR_MESSAGE);
            return; // Exit if validation fails
        }
        //validate numeric
        try {
            Integer.valueOf(noot);
            Integer.valueOf(pin);
            Integer.valueOf(po);
            Integer.valueOf(ic);
            Integer.parseInt(sa);
            Integer.parseInt(re);
            Integer.parseInt(r);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Please enter valid numbers for quantities", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        try {
            Connection con = Dbase.DBConnect();
            // SQL query for inserting values
            String updateQuery = "UPDATE front SET name=?,date=?, pinipig=?, popsicle=?, ice=?, salt=?, remitt=?, ret=? WHERE no=?";

            try (PreparedStatement updateStmt = con.prepareStatement(updateQuery)) {
                updateStmt.setString(1, name.getText());
                if (date_Chooser.getDate() != null) {
                    updateStmt.setDate(2, new java.sql.Date(date_Chooser.getDate().getTime())); // Correctly convert to java.sql.Date
                } else {
                    JOptionPane.showMessageDialog(this, "Please select a date.", "Error", JOptionPane.ERROR_MESSAGE);
                    return; // Exit if date is not selected
                }
                updateStmt.setString(3, pinipig.getText());
                updateStmt.setString(4, popsicle.getText());
                updateStmt.setString(5, ice.getText());
                updateStmt.setString(6, salt.getText());
                updateStmt.setString(7, remitt.getText());
                updateStmt.setString(8, ret.getText());
                updateStmt.setString(9, noo.getText());

                // Execute the update statement
                int rowsAffected = updateStmt.executeUpdate();
                if (rowsAffected > 0) {

                    DefaultTableModel tb1Model = (DefaultTableModel) table.getModel();
                    // Update the table model with new values
                    int selectedRow = table.getSelectedRow(); // Get the currently selected row
                    tb1Model.setValueAt(noot, selectedRow, 0);
                    tb1Model.setValueAt(name.getText(), selectedRow, 1);
                    tb1Model.setValueAt(new java.sql.Date(date_Chooser.getDate().getTime()), selectedRow, 2);
                    tb1Model.setValueAt(pin, selectedRow, 3);
                    tb1Model.setValueAt(po, selectedRow, 4);
                    tb1Model.setValueAt(ic, selectedRow, 5);
                    tb1Model.setValueAt(sa, selectedRow, 6);
                    tb1Model.setValueAt(re, selectedRow, 7);
                    tb1Model.setValueAt(r, selectedRow, 8);
                    loadData(); // Refresh the data in the table
                    JOptionPane.showMessageDialog(null, "Added", "Success", JOptionPane.INFORMATION_MESSAGE);
                } else {
                    // No rows affected
                    JOptionPane.showMessageDialog(this, "Invalid", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        } catch (HeadlessException | SQLException e) {
            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }
    }//GEN-LAST:event_updateActionPerformed

    private void nooActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nooActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_nooActionPerformed

    private void CnameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CnameActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_CnameActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        String nameInput = Cname.getText(); // Assuming nameTextField is your input field for the name
    if (!nameInput.isEmpty()) {
        cnname(nameInput);
    } else {
        JOptionPane.showMessageDialog(this, "Please enter a name.", "Input Error", JOptionPane.ERROR_MESSAGE);
    }
    }//GEN-LAST:event_jButton1ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not availjPanel2with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Front.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Front.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Front.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Front.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Front().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField Cname;
    private javax.swing.JTable Table2;
    private javax.swing.JButton add;
    private javax.swing.JButton addDelivery;
    private javax.swing.JButton chartDelivery;
    private javax.swing.JButton clear;
    private javax.swing.JButton dashDelivery;
    private com.toedter.calendar.JDateChooser date_Chooser;
    private com.toedter.calendar.JDateChooser date_Chooser2;
    private javax.swing.JButton delDelivery;
    private javax.swing.JButton delete;
    private javax.swing.JLabel ee;
    private javax.swing.JPanel four;
    private javax.swing.JLabel fp;
    private javax.swing.JTextField ice;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton3;
    private org.jdatepicker.util.JDatePickerUtil jDatePickerUtil1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel29;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel30;
    private javax.swing.JLabel jLabel31;
    private javax.swing.JLabel jLabel32;
    private javax.swing.JLabel jLabel33;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JTextField jTextField2;
    private javax.swing.JTextField name;
    private javax.swing.JTextField noo;
    private javax.swing.JPanel one;
    private javax.swing.JPanel parentPanel;
    private javax.swing.JTextField pinipig;
    private javax.swing.JTextField popsicle;
    private javax.swing.JLabel pp;
    private javax.swing.JTextField remitt;
    private javax.swing.JTextField ret;
    private javax.swing.JTextField salt;
    private javax.swing.JTable table;
    private javax.swing.JTable table3;
    private javax.swing.JPanel three;
    private javax.swing.JLabel totalp;
    private javax.swing.JLabel totalpop;
    private javax.swing.JPanel two;
    private javax.swing.JButton update;
    // End of variables declaration//GEN-END:variables
}
